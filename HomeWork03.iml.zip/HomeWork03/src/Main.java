public class Main {
    public static void main(String[] args) {

        System.out.println("Иванов Иван Иванович1, возраст: 34 года, рост: 187 см");
        System.out.println();
        System.out.println("Иванов Иван Иванович2, возраст: 35 года, рост: 188 см");
        System.out.println();
        System.out.println("Иванов Иван Иванович3, возраст: 36 года, рост: 189 см");
        System.out.printf("%.2f, %.2f, %.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.println();
        System.out.print("|");
        System.out.print(" |");
        System.out.println();
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
    }
}